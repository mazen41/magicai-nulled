<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ai_image_pro', function (Blueprint $table) {
            $table->unsignedInteger('likes_count')->default(0)->nullable();
            $table->unsignedInteger('views_count')->default(0)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ai_image_pro', function (Blueprint $table) {
            $table->dropColumn(['likes_count', 'views_count']);
        });
    }
};
