<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ai_music_pro', function (Blueprint $table) {
            $table->string('provider', 30)->default('elevenlabs')->after('music_style');
            $table->text('lyrics')->nullable()->after('provider');
        });
    }

    public function down(): void
    {
        Schema::table('ai_music_pro', function (Blueprint $table) {
            $table->dropColumn(['provider', 'lyrics']);
        });
    }
};
