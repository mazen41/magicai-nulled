<?php

return [
    'enabled' => true,
];
